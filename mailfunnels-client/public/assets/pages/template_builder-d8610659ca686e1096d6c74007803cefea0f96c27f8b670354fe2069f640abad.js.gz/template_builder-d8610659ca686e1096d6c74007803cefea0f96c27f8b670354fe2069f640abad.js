$(function() {


    alert("Hello");

    $("#contentarea").contentbuilder();

});
